import Home from './Home'
import Album from './Album'
import Dashboard from './Dashboard'
import Hold from './Hold'

export { Hold, Home, Album, Dashboard }