import React from "react";
// import FooterMenu from "../components/FooterMenu; ";

//style
import '../components/styleSheets/sk.css';

const Dashboard = () => {
    return (
        <div>
            <div className="opener">
                Dashboard
            </div>
            {/* <FooterMenu /> */}
        </div>
    );
};

export default Dashboard;
