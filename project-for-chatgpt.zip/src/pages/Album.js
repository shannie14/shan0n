import React from "react";
// import FooterMenu from "../components/FooterMenu; ";

//style
import '../components/styleSheets/sk.css';

const Album = () => {
    return (
        <div>
            <div className="opener">
                Album
            </div>
            {/* <FooterMenu /> */}
        </div>
    );
};

export default Album;
